"use client"

import { CheckCircle, X } from "lucide-react"
import { useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface SuccessModalProps {
  isOpen: boolean
  message: string
  onClose: () => void
  autoClose?: number
}

export function SuccessModal({ isOpen, message, onClose, autoClose = 3000 }: SuccessModalProps) {
  useEffect(() => {
    if (isOpen && autoClose) {
      const timer = setTimeout(onClose, autoClose)
      return () => clearTimeout(timer)
    }
  }, [isOpen, autoClose, onClose])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <Card className="relative w-full max-w-md mx-4 border-2 border-green-500 dark:border-green-400 bg-card shadow-2xl animate-in zoom-in duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 p-1 hover:bg-muted rounded-full transition-colors">
          <X size={20} />
        </button>

        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-2">
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full">
              <CheckCircle size={48} className="text-green-600 dark:text-green-400" />
            </div>
          </div>
          <CardTitle className="text-2xl text-foreground">{message}</CardTitle>
        </CardHeader>

        <CardContent className="text-center">
          <p className="text-sm text-muted-foreground">This will close automatically in a few seconds</p>
        </CardContent>
      </Card>
    </div>
  )
}
