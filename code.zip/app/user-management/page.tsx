"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Trash2, Shield, Lock, Unlock, DollarSign, Calendar } from "lucide-react"

interface User {
  id: number
  username: string
  email: string
  role: "owner" | "admin" | "user"
  status: "active" | "blocked"
  plan: string
  balance: number
  plan_expiry_date: string | null
  created_at: string
}

interface BalanceModal {
  isOpen: boolean
  userId: number | null
  username: string
  currentBalance: number
  action: "add" | "remove"
}

interface PlanModal {
  isOpen: boolean
  userId: number | null
  username: string
  currentPlan: string
}

export default function UserManagementPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [balanceModal, setBalanceModal] = useState<BalanceModal>({
    isOpen: false,
    userId: null,
    username: "",
    currentBalance: 0,
    action: "add",
  })
  const [balanceAmount, setBalanceAmount] = useState("")
  const [planModal, setPlanModal] = useState<PlanModal>({
    isOpen: false,
    userId: null,
    username: "",
    currentPlan: "",
  })

  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/login")
        return
      }

      const { data: userData } = await supabase.from("users").select("*").eq("auth_id", user.id).single()

      if (!userData || userData.role !== "owner") {
        router.push("/dashboard")
        return
      }

      setSession(userData)

      const { data: allUsers, error } = await supabase
        .from("users")
        .select("*")
        .order("created_at", { ascending: false })

      if (!error && allUsers) {
        setUsers(allUsers)
      }

      setLoading(false)
    }

    loadData()
  }, [router])

  const openBalanceModal = (userId: number, username: string, currentBalance: number, action: "add" | "remove") => {
    setBalanceModal({
      isOpen: true,
      userId,
      username,
      currentBalance,
      action,
    })
    setBalanceAmount("")
  }

  const confirmBalanceChange = async () => {
    if (!balanceModal.userId || !balanceAmount) return

    const amount = Number.parseFloat(balanceAmount)
    if (isNaN(amount) || amount <= 0) {
      alert("Please enter a valid amount")
      return
    }

    const supabase = createClient()
    const user = users.find((u) => u.id === balanceModal.userId)
    if (!user) return

    const newBalance = balanceModal.action === "add" ? user.balance + amount : Math.max(0, user.balance - amount)

    const { error } = await supabase.from("users").update({ balance: newBalance }).eq("id", balanceModal.userId)

    if (!error) {
      setUsers(users.map((u) => (u.id === balanceModal.userId ? { ...u, balance: newBalance } : u)))
      setBalanceModal({ isOpen: false, userId: null, username: "", currentBalance: 0, action: "add" })
      setBalanceAmount("")
      alert(`Successfully ${balanceModal.action === "add" ? "added" : "removed"} $${amount}`)
    } else {
      alert("Failed to update balance")
    }
  }

  const openPlanModal = (userId: number, username: string, currentPlan: string) => {
    setPlanModal({
      isOpen: true,
      userId,
      username,
      currentPlan,
    })
  }

  const confirmPlanChange = async (newPlan: string) => {
    if (!planModal.userId) return

    const supabase = createClient()

    // Calculate expiry date based on plan
    let expiryDate: string | null = null
    const now = new Date()

    switch (newPlan) {
      case "premium-3d":
        now.setDate(now.getDate() + 3)
        expiryDate = now.toISOString()
        break
      case "premium-7d":
        now.setDate(now.getDate() + 7)
        expiryDate = now.toISOString()
        break
      case "premium-14d":
        now.setDate(now.getDate() + 14)
        expiryDate = now.toISOString()
        break
      case "premium-30d":
        now.setDate(now.getDate() + 30)
        expiryDate = now.toISOString()
        break
      case "lifetime":
        expiryDate = null // No expiry for lifetime
        break
      default:
        expiryDate = null // Free plan has no expiry
    }

    const { error } = await supabase
      .from("users")
      .update({
        plan: newPlan,
        plan_expiry_date: expiryDate,
      })
      .eq("id", planModal.userId)

    if (!error) {
      setUsers(
        users.map((u) =>
          u.id === planModal.userId
            ? {
                ...u,
                plan: newPlan,
                plan_expiry_date: expiryDate,
              }
            : u,
        ),
      )
      setPlanModal({ isOpen: false, userId: null, username: "", currentPlan: "" })
      alert(`Plan updated to ${newPlan.toUpperCase()}`)
    } else {
      alert("Failed to update plan")
    }
  }

  const handleMakeAdmin = async (userId: number) => {
    const supabase = createClient()
    const { error } = await supabase.from("users").update({ role: "admin" }).eq("id", userId)

    if (!error) {
      setUsers(users.map((user) => (user.id === userId ? { ...user, role: "admin" as const } : user)))
    }
  }

  const handleRemoveAdmin = async (userId: number) => {
    const supabase = createClient()
    const { error } = await supabase.from("users").update({ role: "user" }).eq("id", userId)

    if (!error) {
      setUsers(users.map((user) => (user.id === userId ? { ...user, role: "user" as const } : user)))
    }
  }

  const handleBlockUser = async (userId: number) => {
    const supabase = createClient()
    const user = users.find((u) => u.id === userId)
    if (!user) return

    const newStatus = user.status === "active" ? "blocked" : "active"
    const { error } = await supabase.from("users").update({ status: newStatus }).eq("id", userId)

    if (!error) {
      setUsers(users.map((u) => (u.id === userId ? { ...u, status: newStatus as "active" | "blocked" } : u)))
    }
  }

  const handleDeleteUser = async (userId: number) => {
    if (userId === session?.id) {
      alert("Cannot delete your own account")
      return
    }

    if (!confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      return
    }

    const supabase = createClient()
    const { error } = await supabase.from("users").delete().eq("id", userId)

    if (!error) {
      setUsers(users.filter((user) => user.id !== userId))
    } else {
      alert("Failed to delete user")
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case "owner":
        return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
      case "admin":
        return "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
      default:
        return "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400"
    }
  }

  const getPlanDisplay = (plan: string) => {
    const planNames: Record<string, string> = {
      free: "Free",
      "premium-3d": "Premium 3D",
      "premium-7d": "Premium 7D",
      "premium-14d": "Premium 14D",
      "premium-30d": "Premium 30D",
      lifetime: "Lifetime",
    }
    return planNames[plan] || plan.toUpperCase()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    )
  }

  if (!session || session.role !== "owner") return null

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {balanceModal.isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setBalanceModal({ ...balanceModal, isOpen: false })}
          />
          <Card className="relative w-full max-w-md mx-4 border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>{balanceModal.action === "add" ? "Add" : "Remove"} Balance</CardTitle>
              <CardDescription>
                {balanceModal.action === "add" ? "Add credits to" : "Remove credits from"} {balanceModal.username}
                <br />
                Current Balance: ${balanceModal.currentBalance}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Amount ($)</label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="Enter amount"
                  value={balanceAmount}
                  onChange={(e) => setBalanceAmount(e.target.value)}
                  className="mt-1 border-2 border-border"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={confirmBalanceChange} className="flex-1 ripple-button">
                  Confirm
                </Button>
                <Button
                  variant="outline"
                  onClick={() =>
                    setBalanceModal({ isOpen: false, userId: null, username: "", currentBalance: 0, action: "add" })
                  }
                  className="flex-1 ripple-button"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {planModal.isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setPlanModal({ ...planModal, isOpen: false })}
          />
          <Card className="relative w-full max-w-md mx-4 border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Change User Plan</CardTitle>
              <CardDescription>
                Change plan for {planModal.username}
                <br />
                Current: {getPlanDisplay(planModal.currentPlan)}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={planModal.currentPlan === "free" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("free")}
                  className="ripple-button"
                >
                  Free
                </Button>
                <Button
                  variant={planModal.currentPlan === "premium-3d" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("premium-3d")}
                  className="ripple-button"
                >
                  3 Days
                </Button>
                <Button
                  variant={planModal.currentPlan === "premium-7d" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("premium-7d")}
                  className="ripple-button"
                >
                  7 Days
                </Button>
                <Button
                  variant={planModal.currentPlan === "premium-14d" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("premium-14d")}
                  className="ripple-button"
                >
                  14 Days
                </Button>
                <Button
                  variant={planModal.currentPlan === "premium-30d" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("premium-30d")}
                  className="ripple-button"
                >
                  30 Days
                </Button>
                <Button
                  variant={planModal.currentPlan === "lifetime" ? "default" : "outline"}
                  onClick={() => confirmPlanChange("lifetime")}
                  className="ripple-button"
                >
                  Lifetime
                </Button>
              </div>
              <Button
                variant="ghost"
                className="w-full ripple-button"
                onClick={() => setPlanModal({ isOpen: false, userId: null, username: "", currentPlan: "" })}
              >
                Cancel
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">User Management</h1>
            <p className="text-muted-foreground">Manage users, credits, and plans (Owner Only)</p>
          </div>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>All Users</CardTitle>
              <CardDescription>
                Total Users: {users.length} | Admins: {users.filter((u) => u.role === "admin").length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-border bg-muted/50">
                      <th className="px-4 py-3 text-left font-semibold">Username</th>
                      <th className="px-4 py-3 text-left font-semibold">Email</th>
                      <th className="px-4 py-3 text-left font-semibold">Role</th>
                      <th className="px-4 py-3 text-left font-semibold">Status</th>
                      <th className="px-4 py-3 text-left font-semibold">Plan</th>
                      <th className="px-4 py-3 text-left font-semibold">Balance</th>
                      <th className="px-4 py-3 text-left font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id} className="border-b border-border hover:bg-muted/50">
                        <td className="px-4 py-3 font-medium">{user.username}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{user.email}</td>
                        <td className="px-4 py-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getRoleColor(user.role)}`}>
                            {user.role.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              user.status === "active"
                                ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                                : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                            }`}
                          >
                            {user.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold">{getPlanDisplay(user.plan)}</span>
                            {user.plan_expiry_date && (
                              <span className="text-xs text-muted-foreground">
                                Exp: {new Date(user.plan_expiry_date).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-semibold text-green-600 dark:text-green-400">${user.balance}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1 flex-wrap">
                            {user.role !== "owner" && (
                              <>
                                <button
                                  onClick={() => openBalanceModal(user.id, user.username, user.balance, "add")}
                                  className="p-2 hover:bg-green-100 text-green-700 dark:hover:bg-green-900/30 dark:text-green-400 rounded transition-colors ripple-button"
                                  title="Add Balance"
                                >
                                  <DollarSign size={16} />
                                </button>
                                <button
                                  onClick={() => openBalanceModal(user.id, user.username, user.balance, "remove")}
                                  className="p-2 hover:bg-red-100 text-red-700 dark:hover:bg-red-900/30 dark:text-red-400 rounded transition-colors ripple-button"
                                  title="Remove Balance"
                                >
                                  <DollarSign size={16} className="rotate-180" />
                                </button>
                                <button
                                  onClick={() => openPlanModal(user.id, user.username, user.plan)}
                                  className="p-2 hover:bg-blue-100 text-blue-700 dark:hover:bg-blue-900/30 dark:text-blue-400 rounded transition-colors ripple-button"
                                  title="Change Plan"
                                >
                                  <Calendar size={16} />
                                </button>
                                {user.role === "user" ? (
                                  <button
                                    onClick={() => handleMakeAdmin(user.id)}
                                    className="p-2 hover:bg-primary/10 text-primary rounded transition-colors ripple-button"
                                    title="Make Admin"
                                  >
                                    <Shield size={16} />
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleRemoveAdmin(user.id)}
                                    className="p-2 hover:bg-yellow-100 text-yellow-700 dark:hover:bg-yellow-900/30 dark:text-yellow-400 rounded transition-colors ripple-button"
                                    title="Remove Admin"
                                  >
                                    <Shield size={16} />
                                  </button>
                                )}
                                <button
                                  onClick={() => handleBlockUser(user.id)}
                                  className={`p-2 rounded transition-colors ripple-button ${
                                    user.status === "active"
                                      ? "hover:bg-destructive/10 text-destructive"
                                      : "hover:bg-green-100 text-green-700 dark:hover:bg-green-900/30 dark:text-green-400"
                                  }`}
                                  title={user.status === "active" ? "Block User" : "Unblock User"}
                                >
                                  {user.status === "active" ? <Lock size={16} /> : <Unlock size={16} />}
                                </button>
                                <button
                                  onClick={() => handleDeleteUser(user.id)}
                                  className="p-2 hover:bg-destructive/10 text-destructive rounded transition-colors ripple-button"
                                  title="Delete User"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
