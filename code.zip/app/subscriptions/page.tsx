"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, AlertCircle } from "lucide-react"

interface SubscriptionPlan {
  id: string
  name: string
  duration: string
  price_credits: number
  description: string
  features: string[]
  isPopular?: boolean
  type: "trial" | "permanent"
}

interface PurchaseModal {
  isOpen: boolean
  plan: SubscriptionPlan | null
  type: "insufficient" | "already_premium" | "confirm" | "success"
}

export default function SubscriptionsPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)
  const [purchaseModal, setPurchaseModal] = useState<PurchaseModal>({
    isOpen: false,
    plan: null,
    type: "confirm",
  })

  useEffect(() => {
    const loadUserData = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/login")
        return
      }

      const { data: userData } = await supabase.from("users").select("*").eq("auth_id", user.id).single()

      if (userData) {
        const sessionData = {
          userId: userData.id,
          username: userData.username,
          role: userData.role,
          plan: userData.plan,
          balance: userData.balance,
          email: userData.email,
          profileImage: userData.profile_picture_url,
          planExpiryDate: userData.plan_expiry_date,
        }
        setSession(sessionData)
        localStorage.setItem("xyriel_session", JSON.stringify(sessionData))
      }
    }

    loadUserData()
  }, [router])

  const subscriptionPlans: SubscriptionPlan[] = [
    {
      id: "free",
      name: "Free Plan",
      duration: "Forever",
      price_credits: 0,
      description: "Perfect for getting started",
      type: "trial",
      features: ["3 total keys", "100 total devices", "Community support", "Basic features"],
    },
    {
      id: "premium-3d",
      name: "Premium Trial",
      duration: "3 Days",
      price_credits: 50,
      description: "Try premium features",
      type: "trial",
      features: ["10 total keys", "300 total devices", "Priority support", "All premium features"],
    },
    {
      id: "premium-7d",
      name: "Premium Trial",
      duration: "7 Days",
      price_credits: 150,
      description: "Extended trial period",
      type: "trial",
      features: ["20 total keys", "700 total devices", "Priority support", "All premium features"],
      isPopular: true,
    },
    {
      id: "premium-14d",
      name: "Premium Trial",
      duration: "14 Days",
      price_credits: 450,
      description: "Full trial experience",
      type: "trial",
      features: ["40 total keys", "Unlimited devices", "Priority support", "All premium features"],
    },
    {
      id: "premium-30d",
      name: "Premium Trial",
      duration: "30 Days",
      price_credits: 700,
      description: "Full month trial",
      type: "trial",
      features: ["Unlimited keys", "Unlimited devices", "Priority support", "All premium features"],
    },
    {
      id: "lifetime",
      name: "Premium Lifetime",
      duration: "Forever",
      price_credits: 1200,
      description: "Lifetime premium access",
      type: "permanent",
      features: ["Unlimited keys", "Unlimited devices", "24/7 priority support", "Exclusive features"],
    },
  ]

  const handleSubscribe = (plan: SubscriptionPlan) => {
    if (plan.id === "free") {
      if (session?.plan === "free") {
        setPurchaseModal({
          isOpen: true,
          plan,
          type: "already_premium",
        })
      }
      return
    }

    // Check if user already has a premium plan
    if (session?.plan !== "free") {
      setPurchaseModal({
        isOpen: true,
        plan,
        type: "already_premium",
      })
      return
    }

    // Check if user has enough balance
    if (session?.balance < plan.price_credits) {
      setPurchaseModal({
        isOpen: true,
        plan,
        type: "insufficient",
      })
      return
    }

    // Show confirmation modal
    setPurchaseModal({
      isOpen: true,
      plan,
      type: "confirm",
    })
  }

  const confirmPurchase = async () => {
    if (!purchaseModal.plan || !session) return

    const supabase = createClient()
    const plan = purchaseModal.plan

    // Calculate expiry date
    let expiryDate: string | null = null
    const now = new Date()

    switch (plan.id) {
      case "premium-3d":
        now.setDate(now.getDate() + 3)
        expiryDate = now.toISOString()
        break
      case "premium-7d":
        now.setDate(now.getDate() + 7)
        expiryDate = now.toISOString()
        break
      case "premium-14d":
        now.setDate(now.getDate() + 14)
        expiryDate = now.toISOString()
        break
      case "premium-30d":
        now.setDate(now.getDate() + 30)
        expiryDate = now.toISOString()
        break
      case "lifetime":
        expiryDate = null
        break
    }

    const newBalance = session.balance - plan.price_credits
    const { error } = await supabase
      .from("users")
      .update({
        balance: newBalance,
        plan: plan.id,
        plan_expiry_date: expiryDate,
      })
      .eq("id", session.userId)

    if (!error) {
      const updatedSession = {
        ...session,
        balance: newBalance,
        plan: plan.id,
        planExpiryDate: expiryDate,
      }
      setSession(updatedSession)
      localStorage.setItem("xyriel_session", JSON.stringify(updatedSession))

      setPurchaseModal({
        isOpen: true,
        plan,
        type: "success",
      })
    } else {
      alert("Purchase failed. Please try again.")
      setPurchaseModal({ isOpen: false, plan: null, type: "confirm" })
    }
  }

  const closeModal = () => {
    setPurchaseModal({ isOpen: false, plan: null, type: "confirm" })
  }

  const trialPlans = subscriptionPlans.filter((p) => p.type === "trial" && p.id !== "free")
  const permanentPlans = subscriptionPlans.filter((p) => p.type === "permanent")
  const freePlan = subscriptionPlans.find((p) => p.id === "free")

  if (!session) return null

  return (
    <div className="min-h-screen bg-background scroll-smooth">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {purchaseModal.isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={closeModal} />
          <Card className="relative w-full max-w-md mx-4 border-2 border-black/20 dark:border-white/20 bg-card shadow-2xl">
            {purchaseModal.type === "insufficient" && (
              <>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="text-red-600 dark:text-red-400" size={24} />
                    <CardTitle>Insufficient Balance</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-foreground">You don't have enough credits to purchase this plan.</p>
                  <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Required:</span>
                      <span className="font-semibold text-foreground">${purchaseModal.plan?.price_credits}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Your Balance:</span>
                      <span className="font-semibold text-red-600 dark:text-red-400">${session.balance}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-border">
                      <span className="text-sm font-medium">Need:</span>
                      <span className="font-semibold text-orange-600 dark:text-orange-400">
                        ${(purchaseModal.plan?.price_credits || 0) - session.balance}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Please contact the owner via Discord or Telegram to add balance to your account.
                  </p>
                  <button
                    onClick={closeModal}
                    className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                  >
                    OK
                  </button>
                </CardContent>
              </>
            )}

            {purchaseModal.type === "already_premium" && (
              <>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="text-blue-600 dark:text-blue-400" size={24} />
                    <CardTitle>Already Have Premium</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-foreground">
                    You already have a {session.plan === "free" ? "Free" : "Premium"} plan.
                  </p>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Current Plan:</span>
                      <span className="font-semibold text-foreground capitalize">{session.plan}</span>
                    </div>
                    {session.planExpiryDate && (
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Expires:</span>
                        <span className="font-semibold text-foreground">
                          {new Date(session.planExpiryDate).toLocaleDateString()}
                        </span>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    If you want to upgrade or change your plan, please message the owner on Discord or Telegram.
                  </p>
                  <button
                    onClick={closeModal}
                    className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                  >
                    OK
                  </button>
                </CardContent>
              </>
            )}

            {purchaseModal.type === "confirm" && (
              <>
                <CardHeader>
                  <CardTitle>Confirm Purchase</CardTitle>
                  <CardDescription>Review your purchase details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Plan:</span>
                      <span className="font-semibold text-foreground">
                        {purchaseModal.plan?.name} ({purchaseModal.plan?.duration})
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Cost:</span>
                      <span className="font-semibold text-foreground">${purchaseModal.plan?.price_credits}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Current Balance:</span>
                      <span className="font-semibold text-foreground">${session.balance}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-border">
                      <span className="text-sm font-medium">New Balance:</span>
                      <span className="font-semibold text-green-600 dark:text-green-400">
                        ${session.balance - (purchaseModal.plan?.price_credits || 0)}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={confirmPurchase}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                    >
                      Confirm Purchase
                    </button>
                    <button
                      onClick={closeModal}
                      className="flex-1 bg-gray-400 hover:bg-gray-500 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                    >
                      Cancel
                    </button>
                  </div>
                </CardContent>
              </>
            )}

            {purchaseModal.type === "success" && (
              <>
                <CardHeader>
                  <div className="flex justify-center mb-2">
                    <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full">
                      <Check size={48} className="text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                  <CardTitle className="text-center">Purchase Successful!</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-center text-foreground">
                    You have successfully purchased {purchaseModal.plan?.name}!
                  </p>
                  <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">New Plan:</span>
                      <span className="font-semibold text-green-600 dark:text-green-400">
                        {purchaseModal.plan?.name}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Remaining Balance:</span>
                      <span className="font-semibold text-foreground">${session.balance}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      closeModal()
                      router.push("/dashboard")
                    }}
                    className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                  >
                    Go to Dashboard
                  </button>
                </CardContent>
              </>
            )}
          </Card>
        </div>
      )}

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold">Subscriptions & Plans</h1>
            <p className="text-muted-foreground">
              Choose the perfect plan for your needs | Your Balance: ${session.balance}
            </p>
          </div>

          {freePlan && (
            <div className="space-y-4">
              <div>
                <h2 className="text-2xl font-bold mb-2">Free Plan</h2>
                <p className="text-muted-foreground mb-4">Start with our free tier, no credit card required</p>
              </div>

              <div className="grid grid-cols-1 gap-6">
                <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
                  <CardHeader>
                    <CardTitle>{freePlan.name}</CardTitle>
                    <CardDescription>{freePlan.duration}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-1">
                      <div className="text-3xl font-bold dark:text-white light:text-black">
                        ${freePlan.price_credits}
                      </div>
                      <div className="text-sm text-muted-foreground dark:text-gray-300 light:text-gray-600">
                        Free Forever
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground">{freePlan.description}</p>

                    <ul className="space-y-2">
                      {freePlan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Check size={16} className="text-green-600 dark:text-green-400" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={() => handleSubscribe(freePlan)}
                      disabled={session?.plan === "free"}
                      className="w-full bg-gray-500 hover:bg-gray-600 disabled:opacity-50 text-white py-2 rounded-lg transition-colors ripple-button"
                    >
                      {session?.plan === "free" ? "Current Plan" : "Get Free"}
                    </button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <h2 className="text-2xl font-bold mb-2">Trial Subscriptions</h2>
              <p className="text-muted-foreground mb-4">Experience premium features with our flexible trial options</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trialPlans.map((plan) => (
                <Card
                  key={plan.id}
                  className={`border-2 border-black/20 dark:border-white/20 relative flex flex-col bg-muted/20 ${
                    plan.isPopular ? "ring-2 ring-primary md:scale-105 bg-card" : ""
                  }`}
                >
                  {plan.isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </div>
                  )}
                  <CardHeader className={plan.isPopular ? "pt-8" : ""}>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>{plan.duration}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 space-y-6">
                    <div className="space-y-1">
                      <div className="text-3xl font-bold dark:text-white light:text-black">${plan.price_credits}</div>
                      <div className="text-sm text-muted-foreground dark:text-gray-300 light:text-gray-600">
                        Credits
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground">{plan.description}</p>

                    <ul className="space-y-2">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Check size={16} className="text-green-600 dark:text-green-400" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={() => handleSubscribe(plan)}
                      className={`w-full py-2 rounded-lg transition-colors ripple-button text-white font-medium ${
                        plan.isPopular ? "bg-primary hover:bg-primary/90" : "bg-primary/50 hover:bg-primary/60"
                      }`}
                    >
                      Purchase Now
                    </button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h2 className="text-2xl font-bold mb-2">Permanent Subscription</h2>
              <p className="text-muted-foreground mb-4">Get lifetime access to premium features</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {permanentPlans.map((plan) => (
                <Card
                  key={plan.id}
                  className="border-2 border-black/20 dark:border-white/20 flex flex-col ring-2 ring-primary bg-card"
                >
                  <CardHeader>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>Lifetime Access</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 space-y-6">
                    <div className="space-y-1">
                      <div className="text-4xl font-bold dark:text-white light:text-black">${plan.price_credits}</div>
                      <div className="text-sm text-muted-foreground dark:text-gray-300 light:text-gray-600">
                        Credits
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground">{plan.description}</p>

                    <ul className="space-y-2">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Check size={16} className="text-green-600 dark:text-green-400" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={() => handleSubscribe(plan)}
                      className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-lg transition-colors ripple-button font-medium"
                    >
                      Get Lifetime Access
                    </button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
