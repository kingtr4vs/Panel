"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Code, Download, Settings, CheckCircle, AlertCircle } from "lucide-react"

export default function APKTutorialPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)

  useEffect(() => {
    const loadUserData = async () => {
      console.log("[v0] APK Tutorial: Starting data load")
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        console.log("[v0] APK Tutorial: No user found, redirecting to login")
        router.push("/login")
        return
      }

      console.log("[v0] APK Tutorial: User found, ID:", user.id)

      const { data: userData, error } = await supabase.from("users").select("*").eq("auth_id", user.id).single()

      if (error) {
        console.log("[v0] APK Tutorial: Error fetching user data:", error)
        return
      }

      if (userData) {
        console.log("[v0] APK Tutorial: User data loaded")
        setSession(userData)
      }
    }

    loadUserData()
  }, [router])

  if (!session) return null

  const steps = [
    {
      icon: Download,
      title: "Step 1: Download the APK",
      description: "Download the APK file from the official source or your developer",
      color: "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
    },
    {
      icon: Settings,
      title: "Step 2: Configure Your APK",
      description: "Add the panel API endpoint and authentication credentials to your APK configuration",
      color: "bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400",
    },
    {
      icon: Code,
      title: "Step 3: Integrate License Check",
      description: "Implement the license verification code in your APK to connect with the panel",
      color: "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400",
    },
    {
      icon: CheckCircle,
      title: "Step 4: Test Connection",
      description: "Test your APK to ensure it successfully connects to the license panel",
      color: "bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold">APK Integration Tutorial</h1>
            <p className="text-muted-foreground">Learn how to connect your APK to the license panel</p>
          </div>

          <Card className="border-2 border-blue-500/50 dark:border-blue-400/50 bg-blue-50/50 dark:bg-blue-950/20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertCircle className="text-blue-600 dark:text-blue-400" size={24} />
                <CardTitle>Important Information</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm text-foreground">
                This tutorial is for developers who want to integrate their Android APK with this license management
                panel.
              </p>
              <p className="text-sm text-foreground">
                Make sure you have basic knowledge of Android development and API integration before proceeding.
              </p>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Integration Steps</h2>

            {steps.map((step, index) => (
              <Card key={index} className="border-2 border-black/20 dark:border-white/20 bg-card">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${step.color}`}>
                      <step.icon size={24} />
                    </div>
                    <div className="flex-1">
                      <CardTitle>{step.title}</CardTitle>
                      <CardDescription className="mt-2">{step.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>API Endpoint Configuration</CardTitle>
              <CardDescription>Use these endpoints in your APK to connect with the panel</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg font-mono text-sm">
                <p className="text-muted-foreground mb-2">Base URL:</p>
                <code className="text-foreground">
                  {typeof window !== "undefined" ? window.location.origin : ""}/api
                </code>
              </div>

              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">Verify License Key:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p className="text-green-600 dark:text-green-400">POST /api/verify-key</p>
                    <p className="text-muted-foreground mt-2">Body: {'{ "key": "YOUR_LICENSE_KEY" }'}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Register Device:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p className="text-green-600 dark:text-green-400">POST /api/register-device</p>
                    <p className="text-muted-foreground mt-2">
                      Body: {'{ "key": "LICENSE_KEY", "device_id": "DEVICE_ID" }'}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Check Device Status:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-xs">
                    <p className="text-green-600 dark:text-green-400">POST /api/check-device</p>
                    <p className="text-muted-foreground mt-2">
                      Body: {'{ "key": "LICENSE_KEY", "device_id": "DEVICE_ID" }'}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Sample Android Code</CardTitle>
              <CardDescription>Example implementation for your APK</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-muted rounded-lg overflow-x-auto">
                <pre className="text-xs font-mono">
                  <code className="text-foreground">{`// Kotlin Example
import okhttp3.*
import org.json.JSONObject

class LicenseManager {
    private val client = OkHttpClient()
    private val baseUrl = "${typeof window !== "undefined" ? window.location.origin : ""}/api"
    
    fun verifyLicense(key: String, callback: (Boolean) -> Unit) {
        val json = JSONObject()
        json.put("key", key)
        
        val body = RequestBody.create(
            MediaType.parse("application/json"), 
            json.toString()
        )
        
        val request = Request.Builder()
            .url("\$baseUrl/verify-key")
            .post(body)
            .build()
            
        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                val isValid = response.isSuccessful
                callback(isValid)
            }
            
            override fun onFailure(call: Call, e: IOException) {
                callback(false)
            }
        })
    }
}`}</code>
                </pre>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-500/50 dark:border-green-400/50 bg-green-50/50 dark:bg-green-950/20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-green-600 dark:text-green-400" size={24} />
                <CardTitle>Need Help?</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-foreground">
                If you need assistance with APK integration, please contact the panel owner via Discord or Telegram for
                detailed support and documentation.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
