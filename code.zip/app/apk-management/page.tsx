"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Trash2, Plus, Smartphone } from "lucide-react"

interface APK {
  id: number
  name: string
  package_name: string
  version: string
  added_date: string
  status: "active" | "inactive"
}

interface AddAPKModal {
  isOpen: boolean
}

export default function APKManagementPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)
  const [apks, setApks] = useState<APK[]>([])
  const [loading, setLoading] = useState(true)
  const [addModal, setAddModal] = useState<AddAPKModal>({ isOpen: false })
  const [newAPK, setNewAPK] = useState({
    name: "",
    package_name: "",
    version: "",
  })

  useEffect(() => {
    const loadData = async () => {
      console.log("[v0] APK Management: Starting data load")
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        console.log("[v0] APK Management: No user found, redirecting to login")
        router.push("/login")
        return
      }

      console.log("[v0] APK Management: User found, ID:", user.id)

      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("auth_id", user.id)
        .single()

      if (userError) {
        console.log("[v0] APK Management: Error fetching user data:", userError)
        setLoading(false)
        return
      }

      if (!userData || userData.role !== "owner") {
        console.log("[v0] APK Management: User is not owner, redirecting")
        router.push("/dashboard")
        return
      }

      console.log("[v0] APK Management: User data loaded:", userData)
      setSession(userData)

      const { data: apkData, error } = await supabase
        .from("connected_apks")
        .select("*")
        .order("added_date", { ascending: false })

      if (error) {
        console.log("[v0] APK Management: Error fetching APKs:", error)
      } else if (apkData) {
        console.log("[v0] APK Management: APKs loaded:", apkData.length)
        setApks(apkData)
      }

      setLoading(false)
    }

    loadData()
  }, [router])

  const handleAddAPK = async () => {
    if (!newAPK.name || !newAPK.package_name || !newAPK.version) {
      alert("Please fill in all fields")
      return
    }

    const supabase = createClient()
    const { data, error } = await supabase
      .from("connected_apks")
      .insert([
        {
          name: newAPK.name,
          package_name: newAPK.package_name,
          version: newAPK.version,
          status: "active",
        },
      ])
      .select()

    if (!error && data) {
      setApks([...apks, data[0]])
      setAddModal({ isOpen: false })
      setNewAPK({ name: "", package_name: "", version: "" })
      alert("APK added successfully!")
    } else {
      alert("Failed to add APK")
    }
  }

  const handleDeleteAPK = async (id: number) => {
    if (!confirm("Are you sure you want to delete this APK?")) return

    const supabase = createClient()
    const { error } = await supabase.from("connected_apks").delete().eq("id", id)

    if (!error) {
      setApks(apks.filter((apk) => apk.id !== id))
      alert("APK deleted successfully!")
    } else {
      alert("Failed to delete APK")
    }
  }

  const handleToggleStatus = async (id: number) => {
    const apk = apks.find((a) => a.id === id)
    if (!apk) return

    const newStatus = apk.status === "active" ? "inactive" : "active"
    const supabase = createClient()
    const { error } = await supabase.from("connected_apks").update({ status: newStatus }).eq("id", id)

    if (!error) {
      setApks(apks.map((a) => (a.id === id ? { ...a, status: newStatus } : a)))
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    )
  }

  if (!session || session.role !== "owner") return null

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {addModal.isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setAddModal({ isOpen: false })}
          />
          <Card className="relative w-full max-w-md mx-4 border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Add New APK</CardTitle>
              <CardDescription>Connect a new APK to your panel</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">APK Name</label>
                <Input
                  placeholder="e.g., My Gaming App"
                  value={newAPK.name}
                  onChange={(e) => setNewAPK({ ...newAPK, name: e.target.value })}
                  className="mt-1 border-2 border-border"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Package Name</label>
                <Input
                  placeholder="e.g., com.example.app"
                  value={newAPK.package_name}
                  onChange={(e) => setNewAPK({ ...newAPK, package_name: e.target.value })}
                  className="mt-1 border-2 border-border"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Version</label>
                <Input
                  placeholder="e.g., 1.0.0"
                  value={newAPK.version}
                  onChange={(e) => setNewAPK({ ...newAPK, version: e.target.value })}
                  className="mt-1 border-2 border-border"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddAPK} className="flex-1 ripple-button">
                  Add APK
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setAddModal({ isOpen: false })}
                  className="flex-1 ripple-button"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">APK Management</h1>
              <p className="text-muted-foreground">Manage connected APKs (Owner Only)</p>
            </div>
            <Button onClick={() => setAddModal({ isOpen: true })} className="ripple-button">
              <Plus size={20} className="mr-2" />
              Add APK
            </Button>
          </div>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Connected APKs</CardTitle>
              <CardDescription>Total APKs: {apks.length}</CardDescription>
            </CardHeader>
            <CardContent>
              {apks.length === 0 ? (
                <div className="text-center py-12">
                  <Smartphone size={48} className="mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No APKs connected yet</p>
                  <Button onClick={() => setAddModal({ isOpen: true })} className="mt-4 ripple-button">
                    Add Your First APK
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b-2 border-border bg-muted/50">
                        <th className="px-4 py-3 text-left font-semibold">APK Name</th>
                        <th className="px-4 py-3 text-left font-semibold">Package Name</th>
                        <th className="px-4 py-3 text-left font-semibold">Version</th>
                        <th className="px-4 py-3 text-left font-semibold">Status</th>
                        <th className="px-4 py-3 text-left font-semibold">Added Date</th>
                        <th className="px-4 py-3 text-left font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {apks.map((apk) => (
                        <tr key={apk.id} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-3 font-medium">{apk.name}</td>
                          <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{apk.package_name}</td>
                          <td className="px-4 py-3 text-sm">{apk.version}</td>
                          <td className="px-4 py-3">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                apk.status === "active"
                                  ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                                  : "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400"
                              }`}
                            >
                              {apk.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">
                            {new Date(apk.added_date).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleToggleStatus(apk.id)}
                                className={`px-3 py-1 rounded text-xs font-semibold transition-colors ripple-button ${
                                  apk.status === "active"
                                    ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400"
                                    : "bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400"
                                }`}
                              >
                                {apk.status === "active" ? "Deactivate" : "Activate"}
                              </button>
                              <button
                                onClick={() => handleDeleteAPK(apk.id)}
                                className="p-2 hover:bg-destructive/10 text-destructive rounded transition-colors ripple-button"
                                title="Delete APK"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
