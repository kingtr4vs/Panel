"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { XYRIEL_CONFIG } from "@/lib/config"

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [email, setEmail] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("signin")
  const [logoError, setLogoError] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")

  console.log("[v0] Login page rendering, activeTab:", activeTab)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    console.log("[v0] Login attempt started")

    try {
      const supabase = createClient()

      const signInPromise = supabase.auth.signInWithPassword({
        email,
        password,
      })

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Login timeout. Please try again.")), 10000),
      )

      const { data, error: signInError } = (await Promise.race([signInPromise, timeoutPromise])) as any

      if (signInError) throw signInError

      console.log("[v0] Login successful, fetching user data")

      if (data.user) {
        const userDataPromise = supabase.from("users").select("*").eq("auth_id", data.user.id).single()

        const userTimeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Failed to load user data. Please try again.")), 5000),
        )

        const { data: userData, error: userError } = (await Promise.race([userDataPromise, userTimeoutPromise])) as any

        if (userError) {
          console.error("[v0] Error fetching user data:", userError)
          throw new Error("Failed to load user data. Please contact support.")
        }

        console.log("[v0] User data loaded, redirecting to dashboard")

        const sessionData = {
          userId: userData.id,
          username: userData.username,
          role: userData.role,
          plan: userData.plan,
          balance: userData.balance,
          email: userData.email,
          profileImage: userData.profile_picture_url,
          planExpiryDate: userData.plan_expiry_date,
        }
        localStorage.setItem("xyriel_session", JSON.stringify(sessionData))

        router.push("/dashboard")
      }
    } catch (err: any) {
      console.error("[v0] Login error:", err)
      setError(err.message || "Invalid email or password")
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccessMessage("")
    setIsLoading(true)

    console.log("[v0] Registration attempt started")

    try {
      if (!username || !email || !password || !confirmPassword) {
        setError("All fields are required")
        setIsLoading(false)
        return
      }

      if (password !== confirmPassword) {
        setError("Passwords do not match")
        setIsLoading(false)
        return
      }

      if (password.length < 6) {
        setError("Password must be at least 6 characters")
        setIsLoading(false)
        return
      }

      const supabase = createClient()

      const signUpPromise = supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
          data: {
            username: username,
            role: "user",
          },
        },
      })

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Registration timeout. Please try again.")), 10000),
      )

      const { data, error: signUpError } = (await Promise.race([signUpPromise, timeoutPromise])) as any

      if (signUpError) throw signUpError

      console.log("[v0] Registration successful")

      if (data.user) {
        setSuccessMessage("Registration successful! You can now sign in with your credentials.")
        setActiveTab("signin")
        setEmail("")
        setPassword("")
        setConfirmPassword("")
        setUsername("")
      }
    } catch (err: any) {
      console.error("[v0] Registration error:", err)
      setError(err.message || "Registration failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            {!logoError ? (
              <img
                src={XYRIEL_CONFIG.panelLogo || "/placeholder.svg"}
                alt="Panel Logo"
                onError={() => setLogoError(true)}
                className="w-12 h-12 rounded-lg"
              />
            ) : (
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold text-xl">
                X
              </div>
            )}
          </div>
          <h1 className="text-3xl font-bold text-foreground">{XYRIEL_CONFIG.panelName}</h1>
          <p className="text-muted-foreground">{XYRIEL_CONFIG.panelDescription}</p>
        </div>

        <Card className="border-border bg-card">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-muted">
              <TabsTrigger value="signin" className="ripple-button data-[state=active]:bg-background">
                Sign In
              </TabsTrigger>
              <TabsTrigger value="register" className="ripple-button data-[state=active]:bg-background">
                Register
              </TabsTrigger>
            </TabsList>

            {/* Sign In Tab */}
            <TabsContent value="signin" className="space-y-4">
              <CardHeader>
                <CardTitle className="text-card-foreground">Sign In</CardTitle>
                <CardDescription>Enter your credentials to access the panel</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  {error && (
                    <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
                      {error}
                    </div>
                  )}
                  {successMessage && (
                    <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-600 dark:text-green-400 text-sm">
                      {successMessage}
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Email</label>
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Password</label>
                    <Input
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 ripple-button"
                    disabled={isLoading}
                  >
                    {isLoading ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
              </CardContent>
            </TabsContent>

            {/* Register Tab */}
            <TabsContent value="register" className="space-y-4">
              <CardHeader>
                <CardTitle className="text-card-foreground">Create Account</CardTitle>
                <CardDescription>Sign up to get started with {XYRIEL_CONFIG.panelName}</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegister} className="space-y-4">
                  {error && (
                    <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
                      {error}
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Username</label>
                    <Input
                      type="text"
                      placeholder="Choose a username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Email</label>
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Password</label>
                    <Input
                      type="password"
                      placeholder="Create a password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Confirm Password</label>
                    <Input
                      type="password"
                      placeholder="Confirm your password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="bg-background text-foreground border-input"
                      disabled={isLoading}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 ripple-button"
                    disabled={isLoading}
                  >
                    {isLoading ? "Creating account..." : "Register"}
                  </Button>
                </form>
              </CardContent>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  )
}
