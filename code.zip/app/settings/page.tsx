"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Copy, Eye, EyeOff, Send } from "lucide-react"

interface CommunityModal {
  isOpen: boolean
  type: "discord" | "telegram" | null
}

export default function SettingsPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)
  const [showPassword, setShowPassword] = useState(false)
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [email, setEmail] = useState("")
  const [profileImage, setProfileImage] = useState<string | null>(null)
  const [communityModal, setCommunityModal] = useState<CommunityModal>({ isOpen: false, type: null })

  useEffect(() => {
    const loadUserData = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/login")
        return
      }

      const { data: userData } = await supabase.from("users").select("*").eq("auth_id", user.id).single()

      if (userData) {
        const sessionData = {
          userId: userData.id,
          username: userData.username,
          role: userData.role,
          plan: userData.plan,
          balance: userData.balance,
          email: userData.email,
          profileImage: userData.profile_picture_url,
          planExpiryDate: userData.plan_expiry_date,
        }
        setSession(sessionData)
        setEmail(userData.email)
        setProfileImage(userData.profile_picture_url)
        localStorage.setItem("xyriel_session", JSON.stringify(sessionData))
      }
    }

    loadUserData()
  }, [router])

  const handlePasswordChange = async () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match")
      return
    }

    if (newPassword.length < 6) {
      alert("Password must be at least 6 characters")
      return
    }

    const supabase = createClient()
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (!error) {
      alert("Password changed successfully")
      setNewPassword("")
      setConfirmPassword("")
    } else {
      alert("Failed to change password")
    }
  }

  const handleCommunityClick = (type: "discord" | "telegram") => {
    setCommunityModal({ isOpen: true, type })
  }

  const closeCommunityModal = () => {
    setCommunityModal({ isOpen: false, type: null })
  }

  const handleProfilePictureUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (!file.type.match(/image\/(jpg|jpeg|png)/)) {
        alert("Only JPG and PNG files are allowed")
        return
      }

      const reader = new FileReader()
      reader.onload = async (e) => {
        const imageData = e.target?.result as string
        setProfileImage(imageData)

        const supabase = createClient()
        const { error } = await supabase
          .from("users")
          .update({ profile_picture_url: imageData })
          .eq("id", session.userId)

        if (!error) {
          const updatedSession = { ...session, profileImage: imageData }
          setSession(updatedSession)
          localStorage.setItem("xyriel_session", JSON.stringify(updatedSession))
          window.dispatchEvent(new Event("storage"))
          alert("Profile picture updated successfully!")
        } else {
          alert("Failed to update profile picture")
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("Copied to clipboard!")
  }

  if (!session) return null

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {communityModal.isOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={closeCommunityModal} />
          <Card className="relative w-full max-w-md mx-4 border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Join Community to Add Balance</CardTitle>
              <CardDescription>Choose a platform to join and upgrade your plan or add balance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                You selected {communityModal.type === "discord" ? "Discord" : "Telegram"}. Please join the community
                first, then you can upgrade your plan or add balance.
              </p>
              <div className="flex gap-2">
                <a
                  href={communityModal.type === "discord" ? "https://discord.gg/xyriel" : "https://t.me/xyriel"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full ripple-button">
                    Open {communityModal.type === "discord" ? "Discord" : "Telegram"}
                  </Button>
                </a>
                <Button variant="outline" onClick={closeCommunityModal} className="flex-1 ripple-button bg-transparent">
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-6 max-w-2xl">
          <div>
            <h1 className="text-3xl font-bold">Settings</h1>
            <p className="text-muted-foreground">Manage your account and preferences</p>
          </div>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Profile</CardTitle>
              <CardDescription>Update your profile information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-2xl overflow-hidden">
                  {profileImage ? (
                    <img
                      src={profileImage || "/placeholder.svg"}
                      alt="Profile"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    session.username.charAt(0).toUpperCase()
                  )}
                </div>
                <label className="cursor-pointer ripple-button">
                  <input
                    type="file"
                    accept=".jpg,.jpeg,.png"
                    onChange={handleProfilePictureUpload}
                    className="hidden"
                  />
                  <Button variant="outline" className="gap-2 cursor-pointer bg-transparent" asChild>
                    <span>
                      <Upload size={18} />
                      Upload Picture
                    </span>
                  </Button>
                </label>
              </div>

              <div>
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  value={email}
                  disabled
                  placeholder="your.email@example.com"
                  className="mt-1 border-2 border-border bg-muted/50"
                />
                <p className="text-xs text-muted-foreground mt-1">Email cannot be changed after registration</p>
              </div>

              <div>
                <label className="text-sm font-medium">Username</label>
                <Input value={session.username} disabled className="mt-1 border-2 border-border" />
              </div>

              <div>
                <label className="text-sm font-medium">Role</label>
                <Input value={session.role.toUpperCase()} disabled className="mt-1 border-2 border-border" />
              </div>

              <div>
                <label className="text-sm font-medium">Plan</label>
                <Input value={session.plan.toUpperCase()} disabled className="mt-1 border-2 border-border" />
              </div>

              <div>
                <label className="text-sm font-medium">Balance</label>
                <div className="flex gap-2 mt-1">
                  <Input value={`$${session.balance}`} disabled className="flex-1 border-2 border-border" />
                  <Button
                    variant="outline"
                    onClick={() => handleCommunityClick("discord")}
                    className="whitespace-nowrap ripple-button"
                  >
                    Add Balance
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Join Discord or Telegram to add balance or upgrade your plan
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Credentials</CardTitle>
              <CardDescription>Your account credentials</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Username</p>
                    <p className="font-mono text-sm">{session.username}</p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(session.username)}
                    className="p-2 hover:bg-background rounded transition-colors ripple-button"
                  >
                    <Copy size={18} />
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>Update your account password</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">New Password</label>
                <div className="relative mt-1">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter new password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="border-2 border-border"
                  />
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-muted-foreground hover:text-foreground ripple-button"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Confirm Password</label>
                <Input
                  type="password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="mt-1 border-2 border-border"
                />
              </div>

              <Button onClick={handlePasswordChange} className="w-full bg-primary hover:bg-primary/90 ripple-button">
                Update Password
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Community</CardTitle>
              <CardDescription>Join our community channels</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <button
                onClick={() => handleCommunityClick("discord")}
                className="w-full flex items-center gap-3 p-3 border-2 border-border rounded-lg hover:bg-muted transition-colors text-left ripple-button"
              >
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0">
                  D
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">Discord Server</p>
                  <p className="text-sm text-muted-foreground">Join our Discord community</p>
                </div>
                <Send size={18} className="text-muted-foreground flex-shrink-0" />
              </button>

              <button
                onClick={() => handleCommunityClick("telegram")}
                className="w-full flex items-center gap-3 p-3 border-2 border-border rounded-lg hover:bg-muted transition-colors text-left ripple-button"
              >
                <div className="w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0">
                  T
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">Telegram Channel</p>
                  <p className="text-sm text-muted-foreground">Follow us on Telegram</p>
                </div>
                <Send size={18} className="text-muted-foreground flex-shrink-0" />
              </button>
            </CardContent>
          </Card>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Subscription Status</CardTitle>
              <CardDescription>Your current plan and expiry information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Current Plan:</span>
                  <span className="font-semibold">{session?.plan?.toUpperCase() || "FREE"}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Plan Status:</span>
                  {session?.plan === "lifetime" ? (
                    <span className="text-lg">∞ Lifetime</span>
                  ) : session?.planExpiryDate ? (
                    <span className="font-semibold">{new Date(session.planExpiryDate).toLocaleDateString()}</span>
                  ) : (
                    <span className="font-semibold">No Expiry</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
