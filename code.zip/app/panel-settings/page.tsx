"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Save } from "lucide-react"
import { XYRIEL_CONFIG } from "@/lib/config"

export default function PanelSettingsPage() {
  const router = useRouter()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [session, setSession] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [panelName, setPanelName] = useState(XYRIEL_CONFIG.panelName)
  const [panelLogo, setPanelLogo] = useState(XYRIEL_CONFIG.panelLogo)

  useEffect(() => {
    const loadData = async () => {
      console.log("[v0] Panel Settings: Starting data load")
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        console.log("[v0] Panel Settings: No user found, redirecting to login")
        router.push("/login")
        return
      }

      console.log("[v0] Panel Settings: User found, ID:", user.id)

      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("auth_id", user.id)
        .single()

      if (userError) {
        console.log("[v0] Panel Settings: Error fetching user data:", userError)
        setLoading(false)
        return
      }

      if (!userData || userData.role !== "owner") {
        console.log("[v0] Panel Settings: User is not owner, redirecting")
        router.push("/dashboard")
        return
      }

      console.log("[v0] Panel Settings: User data loaded")
      setSession(userData)

      const { data: settingsData, error: settingsError } = await supabase.from("panel_settings").select("*").single()

      if (settingsError) {
        console.log("[v0] Panel Settings: Error or no settings found:", settingsError)
      } else if (settingsData) {
        console.log("[v0] Panel Settings: Settings loaded")
        setPanelName(settingsData.panel_name || XYRIEL_CONFIG.panelName)
        setPanelLogo(settingsData.panel_logo || XYRIEL_CONFIG.panelLogo)
      }

      setLoading(false)
    }

    loadData()
  }, [router])

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (!file.type.match(/image\/(jpg|jpeg|png)/)) {
        alert("Only JPG and PNG files are allowed")
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        const imageData = e.target?.result as string
        setPanelLogo(imageData)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveSettings = async () => {
    const supabase = createClient()

    const { data: existingSettings } = await supabase.from("panel_settings").select("*").single()

    if (existingSettings) {
      const { error } = await supabase
        .from("panel_settings")
        .update({
          panel_name: panelName,
          panel_logo: panelLogo,
        })
        .eq("id", existingSettings.id)

      if (!error) {
        alert("Panel settings updated successfully!")
        window.location.reload()
      } else {
        alert("Failed to update settings")
      }
    } else {
      const { error } = await supabase.from("panel_settings").insert([
        {
          panel_name: panelName,
          panel_logo: panelLogo,
        },
      ])

      if (!error) {
        alert("Panel settings saved successfully!")
        window.location.reload()
      } else {
        alert("Failed to save settings")
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    )
  }

  if (!session || session.role !== "owner") return null

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={setIsSidebarOpen} isSidebarOpen={isSidebarOpen} />
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      <main className="pt-20 md:ml-64 p-4 md:p-6">
        <div className="space-y-6 max-w-2xl">
          <div>
            <h1 className="text-3xl font-bold">Panel Settings</h1>
            <p className="text-muted-foreground">Customize your panel appearance (Owner Only)</p>
          </div>

          <Card className="border-2 border-black/20 dark:border-white/20 bg-card">
            <CardHeader>
              <CardTitle>Panel Branding</CardTitle>
              <CardDescription>Customize your panel name and logo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="text-sm font-medium">Panel Name</label>
                <Input
                  value={panelName}
                  onChange={(e) => setPanelName(e.target.value)}
                  placeholder="Enter panel name"
                  className="mt-1 border-2 border-border"
                />
                <p className="text-xs text-muted-foreground mt-1">This will appear in the sidebar and header</p>
              </div>

              <div>
                <label className="text-sm font-medium">Panel Logo</label>
                <div className="flex items-center gap-4 mt-2">
                  <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold text-2xl overflow-hidden">
                    {panelLogo ? (
                      <img
                        src={panelLogo || "/placeholder.svg"}
                        alt="Panel Logo"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      "X"
                    )}
                  </div>
                  <label className="cursor-pointer ripple-button">
                    <input type="file" accept=".jpg,.jpeg,.png" onChange={handleLogoUpload} className="hidden" />
                    <Button variant="outline" className="gap-2 cursor-pointer bg-transparent" asChild>
                      <span>
                        <Upload size={18} />
                        Upload Logo
                      </span>
                    </Button>
                  </label>
                </div>
                <p className="text-xs text-muted-foreground mt-2">Recommended size: 512x512px (JPG or PNG)</p>
              </div>

              <Button onClick={handleSaveSettings} className="w-full ripple-button">
                <Save size={18} className="mr-2" />
                Save Settings
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-500/50 dark:border-blue-400/50 bg-blue-50/50 dark:bg-blue-950/20">
            <CardHeader>
              <CardTitle>Preview</CardTitle>
              <CardDescription>See how your changes will look</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-background border-2 border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold text-lg overflow-hidden">
                    {panelLogo ? (
                      <img src={panelLogo || "/placeholder.svg"} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      "X"
                    )}
                  </div>
                  <div>
                    <p className="font-bold text-sm">{panelName}</p>
                    <p className="text-xs text-muted-foreground">Admin Dashboard</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="mt-12 pt-6 border-t border-border text-center text-sm text-muted-foreground">
        <p>© 2025 Made by Xyriel all rights reserved</p>
      </footer>
    </div>
  )
}
