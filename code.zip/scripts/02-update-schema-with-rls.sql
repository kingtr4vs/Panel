-- Enhanced schema with proper RLS policies and APK management

-- Enable RLS on users table
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies before creating to avoid "already exists" errors
DROP POLICY IF EXISTS "Users can view own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Owner can view all users" ON users;
DROP POLICY IF EXISTS "Owner can update all users" ON users;

-- Fixed RLS policies to use email comparison instead of id comparison to avoid uuid/integer type mismatch
-- Users can view their own data
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (email = auth.jwt()->>'email');

-- Users can update their own data
CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (email = auth.jwt()->>'email');

-- Owner can view all users
CREATE POLICY "Owner can view all users" ON users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Owner can update all users
CREATE POLICY "Owner can update all users" ON users
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Enable RLS on license_keys table
ALTER TABLE license_keys ENABLE ROW LEVEL SECURITY;

-- Drop existing policies before creating
DROP POLICY IF EXISTS "Users can view own keys" ON license_keys;
DROP POLICY IF EXISTS "Users can insert own keys" ON license_keys;
DROP POLICY IF EXISTS "Users can update own keys" ON license_keys;
DROP POLICY IF EXISTS "Users can delete own keys" ON license_keys;

-- Users can view their own keys
CREATE POLICY "Users can view own keys" ON license_keys
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = license_keys.user_id
      AND users.email = auth.jwt()->>'email'
    )
  );

-- Users can insert their own keys
CREATE POLICY "Users can insert own keys" ON license_keys
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = license_keys.user_id
      AND users.email = auth.jwt()->>'email'
    )
  );

-- Users can update their own keys
CREATE POLICY "Users can update own keys" ON license_keys
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = license_keys.user_id
      AND users.email = auth.jwt()->>'email'
    )
  );

-- Users can delete their own keys
CREATE POLICY "Users can delete own keys" ON license_keys
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = license_keys.user_id
      AND users.email = auth.jwt()->>'email'
    )
  );

-- Enable RLS on devices table
ALTER TABLE devices ENABLE ROW LEVEL SECURITY;

-- Drop existing policy before creating
DROP POLICY IF EXISTS "Users can view own devices" ON devices;

-- Users can view devices for their keys
CREATE POLICY "Users can view own devices" ON devices
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM license_keys 
      JOIN users ON users.id = license_keys.user_id
      WHERE license_keys.id = devices.key_id 
      AND users.email = auth.jwt()->>'email'
    )
  );

-- Add APK management table
CREATE TABLE IF NOT EXISTS connected_apks (
  id SERIAL PRIMARY KEY,
  apk_name VARCHAR(255) NOT NULL,
  package_name VARCHAR(255) UNIQUE NOT NULL,
  api_key VARCHAR(255) UNIQUE NOT NULL,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  description TEXT,
  version VARCHAR(50),
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'inactive'
  total_users INTEGER DEFAULT 0,
  total_requests INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Enable RLS on connected_apks table
ALTER TABLE connected_apks ENABLE ROW LEVEL SECURITY;

-- Drop existing policies before creating
DROP POLICY IF EXISTS "Only owner can view APKs" ON connected_apks;
DROP POLICY IF EXISTS "Only owner can insert APKs" ON connected_apks;
DROP POLICY IF EXISTS "Only owner can update APKs" ON connected_apks;
DROP POLICY IF EXISTS "Only owner can delete APKs" ON connected_apks;

-- Only owner can view APKs
CREATE POLICY "Only owner can view APKs" ON connected_apks
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Only owner can insert APKs
CREATE POLICY "Only owner can insert APKs" ON connected_apks
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Only owner can update APKs
CREATE POLICY "Only owner can update APKs" ON connected_apks
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Only owner can delete APKs
CREATE POLICY "Only owner can delete APKs" ON connected_apks
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE email = auth.jwt()->>'email'
      AND role = 'owner'
    )
  );

-- Add plan_expiry_date column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS plan_expiry_date TIMESTAMP;
