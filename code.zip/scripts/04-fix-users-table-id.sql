-- Add auth_id column to link with Supabase auth.users
-- This approach preserves existing data and avoids type conversion issues

-- Add auth_id column if it doesn't exist
ALTER TABLE users ADD COLUMN IF NOT EXISTS auth_id UUID UNIQUE;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_users_auth_id ON users(auth_id);

-- Update RLS policies to use auth_id
DROP POLICY IF EXISTS "Users can view own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Owner can view all users" ON users;
DROP POLICY IF EXISTS "Owner can update all users" ON users;

-- Users can view their own data using auth_id
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (auth_id = auth.uid());

-- Users can update their own data using auth_id
CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth_id = auth.uid());

-- Owner can view all users
CREATE POLICY "Owner can view all users" ON users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE auth_id = auth.uid()
      AND role = 'owner'
    )
  );

-- Owner can update all users
CREATE POLICY "Owner can update all users" ON users
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE auth_id = auth.uid()
      AND role = 'owner'
    )
  );

-- Owner can delete users
CREATE POLICY "Owner can delete users" ON users
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE auth_id = auth.uid()
      AND role = 'owner'
    )
  );

-- Allow service role to insert users (for the trigger)
CREATE POLICY "Service role can insert users" ON users
  FOR INSERT WITH CHECK (true);
