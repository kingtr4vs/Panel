-- Create connected_apks table
CREATE TABLE IF NOT EXISTS connected_apks (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  package_name TEXT NOT NULL UNIQUE,
  version TEXT NOT NULL,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  added_date TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE connected_apks ENABLE ROW LEVEL SECURITY;

-- Fixed RLS policy to properly check owner role using email instead of id comparison
-- Policy: Only owners can manage APKs
CREATE POLICY "Owners can manage APKs" ON connected_apks
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.email = auth.jwt()->>'email'
      AND users.role = 'owner'
    )
  );

-- Policy: All authenticated users can view APKs
CREATE POLICY "Authenticated users can view APKs" ON connected_apks
  FOR SELECT
  USING (auth.role() = 'authenticated');

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_apks_package_name ON connected_apks(package_name);
CREATE INDEX IF NOT EXISTS idx_apks_status ON connected_apks(status);
