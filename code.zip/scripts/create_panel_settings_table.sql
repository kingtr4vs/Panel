-- Create panel_settings table
CREATE TABLE IF NOT EXISTS panel_settings (
  id BIGSERIAL PRIMARY KEY,
  panel_name TEXT DEFAULT 'Xyriel Panel',
  panel_logo TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE panel_settings ENABLE ROW LEVEL SECURITY;

-- Fixed RLS policy to properly check owner role using email instead of id comparison
-- Policy: Only owners can manage panel settings
CREATE POLICY "Owners can manage panel settings" ON panel_settings
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.email = auth.jwt()->>'email'
      AND users.role = 'owner'
    )
  );

-- Policy: All authenticated users can view panel settings
CREATE POLICY "Authenticated users can view panel settings" ON panel_settings
  FOR SELECT
  USING (auth.role() = 'authenticated');

-- Insert default settings
INSERT INTO panel_settings (panel_name, panel_logo)
VALUES ('Xyriel Panel', '')
ON CONFLICT DO NOTHING;
